<?php
declare(strict_types=1);

/**
 * Cliente mínimo para Google Gemini API (vision).
 * API key SOLO server-side (nunca se filtra al cliente).
 *
 * Si GEMINI_API_KEY no está definida, isAvailable() === false y el endpoint
 * degrada a modo manual (UI permite completar los campos a mano).
 */
final class GeminiClient
{
    private string $apiKey;
    private string $model;
    private int $timeout;

    // Cadena de fallback: si el modelo principal no existe/no soporta generateContent,
    // intenta automáticamente el siguiente. gemini-1.5-* fue deprecado por Google en 2025.
    private const MODEL_FALLBACKS = [
        'gemini-2.5-flash',
        'gemini-2.0-flash',
        'gemini-2.5-flash-lite',
        'gemini-flash-latest',
    ];

    public function __construct(?string $apiKey = null, ?string $model = null, int $timeout = 90)
    {
        $this->apiKey  = $apiKey  ?? (defined('GEMINI_API_KEY') ? GEMINI_API_KEY : '');
        $this->model   = $model   ?? (defined('GEMINI_MODEL')   ? GEMINI_MODEL   : 'gemini-2.5-flash');
        // Timeout 90s total — permite que HostGator devuelva respuesta antes de 504 del gateway (~120s)
        $this->timeout = $timeout;
    }

    public function isAvailable(): bool { return $this->apiKey !== ''; }

    /**
     * Extrae campos de cliente desde imagen (base64) + mime.
     * Intenta el modelo configurado; si Google responde "not found/not supported",
     * cae automáticamente al siguiente de la cadena de fallback.
     * @return array{phone:?string, company:?string, buyer:?string, material:?string, price_raw:?string, scan_date:?string, notes:?string, confidence:?string}
     */
    public function extractClientFields(string $imageBase64, string $mime): array
    {
        if (!$this->isAvailable()) throw new RuntimeException('gemini_unavailable');

        // Ordena modelos: configurado primero, luego los fallbacks que no sean duplicados
        $models = [$this->model];
        foreach (self::MODEL_FALLBACKS as $m) {
            if ($m !== $this->model) $models[] = $m;
        }

        $lastError = null;
        foreach ($models as $model) {
            try {
                return $this->callModel($model, $imageBase64, $mime);
            } catch (RuntimeException $e) {
                $lastError = $e;
                $msg = $e->getMessage();
                // Si es "modelo no existe/no soporta generateContent", intenta el siguiente
                $looksDeprecated = stripos($msg, 'not found') !== false
                    || stripos($msg, 'not supported') !== false
                    || stripos($msg, 'gemini_http_404') !== false
                    || stripos($msg, 'gemini_http_400') !== false && stripos($msg, 'model') !== false;
                if ($looksDeprecated && $model !== end($models)) {
                    if (function_exists('vs_log')) vs_log('[gemini] model "' . $model . '" no disponible → probando siguiente');
                    continue;
                }
                // Otros errores (auth, quota, red): no reintentes
                throw $e;
            }
        }
        throw $lastError ?: new RuntimeException('gemini_all_models_failed');
    }

    private function callModel(string $model, string $imageBase64, string $mime): array
    {
        $prompt = "Eres un asistente de OCR para ValkamSync, analizando fotos de tarjetas de presentación, "
            . "agendas físicas o notas de clientes del sector de reciclaje de metales.\n\n"
            . "Extrae los campos identificables y retorna EXCLUSIVAMENTE JSON válido:\n"
            . "{\n"
            . "  \"phone\": \"teléfono tal como aparece (con código país si se ve)\",\n"
            . "  \"company\": \"nombre de empresa\",\n"
            . "  \"buyer\": \"nombre de persona de contacto\",\n"
            . "  \"material\": \"material mencionado o null\",\n"
            . "  \"price_raw\": \"precio tal como aparece (ej 1.40, 0.72/Al) o null\",\n"
            . "  \"scan_date\": \"fecha escrita en formato YYYY-MM-DD o null\",\n"
            . "  \"notes\": \"otra info relevante (dirección, email, etc.) o null\",\n"
            . "  \"confidence\": \"alta | media | baja\"\n"
            . "}\n\n"
            . "Reglas: usa null (no string vacío) si no se puede determinar. No inventes datos. "
            . "Retorna SOLO el JSON, sin markdown, sin ```.";

        $body = [
            'contents' => [[
                'parts' => [
                    ['text' => $prompt],
                    ['inline_data' => ['mime_type' => $mime, 'data' => $imageBase64]],
                ],
            ]],
            'generationConfig' => [
                'temperature'        => 0.1,
                // 2048 tokens cubre el JSON completo con notas largas; 800 truncaba con modelos 2.5
                'maxOutputTokens'    => 2048,
                'response_mime_type' => 'application/json',
                // Gemini 2.5 flash usa "thinking tokens" por default que se comen el presupuesto.
                // Para OCR no necesitamos razonamiento → desactivar thinking.
                // Ignorado silenciosamente por modelos <2.5.
                'thinkingConfig'     => ['thinkingBudget' => 0],
            ],
        ];

        $url = sprintf(
            'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
            rawurlencode($model),
            rawurlencode($this->apiKey)
        );

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body, JSON_UNESCAPED_UNICODE),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => $this->timeout,
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_NOSIGNAL       => true,   // evita bloqueos con alarm() en shared hosting
        ]);
        $tStart   = microtime(true);
        $resp     = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err      = curl_error($ch);
        $dlSize   = curl_getinfo($ch, CURLINFO_SIZE_DOWNLOAD);
        curl_close($ch);
        if (function_exists('vs_log')) {
            vs_log(sprintf('[gemini] curl  %.2fs  http=%d  dl=%dB%s',
                microtime(true) - $tStart, $httpCode, (int) $dlSize,
                $err !== '' ? '  err=' . $err : ''
            ));
        }

        if ($resp === false)         throw new RuntimeException("gemini_curl: $err");
        if ($httpCode !== 200) {
            $parsed = json_decode((string) $resp, true);
            $msg = $parsed['error']['message'] ?? 'unknown';
            throw new RuntimeException("gemini_http_$httpCode: $msg");
        }

        $parsed = json_decode((string) $resp, true);
        $text   = $parsed['candidates'][0]['content']['parts'][0]['text'] ?? '';
        $finishReason = $parsed['candidates'][0]['finishReason'] ?? '';

        $fields = json_decode($text, true);
        if (!is_array($fields)) {
            $stripped = preg_replace('/^```(?:json)?\s*|\s*```$/m', '', $text);
            $fields = json_decode((string) $stripped, true);
            if (!is_array($fields)) {
                // Detección específica: respuesta truncada por MAX_TOKENS
                if ($finishReason === 'MAX_TOKENS' || !str_ends_with(rtrim($text), '}')) {
                    throw new RuntimeException('gemini_truncated: respuesta cortada a medio JSON. Aumentar maxOutputTokens o reducir tamaño de imagen.');
                }
                throw new RuntimeException('gemini_bad_json: ' . substr($text, 0, 120));
            }
        }

        return [
            'phone'      => isset($fields['phone'])     ? trim((string) $fields['phone'])     : null,
            'company'    => isset($fields['company'])   ? trim((string) $fields['company'])   : null,
            'buyer'      => isset($fields['buyer'])     ? trim((string) $fields['buyer'])     : null,
            'material'   => isset($fields['material'])  ? trim((string) $fields['material'])  : null,
            'price_raw'  => isset($fields['price_raw']) ? trim((string) $fields['price_raw']) : null,
            'scan_date'  => isset($fields['scan_date']) ? trim((string) $fields['scan_date']) : null,
            'notes'      => isset($fields['notes'])     ? trim((string) $fields['notes'])     : null,
            'confidence' => isset($fields['confidence'])? trim((string) $fields['confidence']): null,
        ];
    }
}

/**
 * Valida, reencoda y redimensiona una imagen subida (master prompt §7).
 * Devuelve binary JPEG listo para pasar a Gemini.
 */
function safe_reencode_image(string $tmpPath, int $maxDim = 1600, int $quality = 85): array
{
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $tmpPath);
    finfo_close($finfo);
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
        throw new RuntimeException('bad_mime');
    }
    $info = @getimagesize($tmpPath);
    if ($info === false) throw new RuntimeException('invalid_image');
    [$w, $h, $type] = $info;
    if ($w <= 0 || $h <= 0) throw new RuntimeException('invalid_dimensions');

    $src = match ($type) {
        IMAGETYPE_JPEG => @imagecreatefromjpeg($tmpPath),
        IMAGETYPE_PNG  => @imagecreatefrompng($tmpPath),
        IMAGETYPE_WEBP => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmpPath) : null,
        default        => null,
    };
    if (!$src) throw new RuntimeException('decode_failed');

    // EXIF orientation (solo JPEG)
    if ($type === IMAGETYPE_JPEG && function_exists('exif_read_data')) {
        $exif = @exif_read_data($tmpPath);
        $orient = (int) ($exif['Orientation'] ?? 1);
        $rotation = match ($orient) { 3 => 180, 6 => -90, 8 => 90, default => 0 };
        if ($rotation !== 0) {
            $rotated = imagerotate($src, $rotation, 0);
            imagedestroy($src);
            $src = $rotated;
            $w = imagesx($src); $h = imagesy($src);
        }
    }

    // Resize
    $ratio = max($w, $h) / $maxDim;
    if ($ratio > 1) {
        $nw = (int) round($w / $ratio);
        $nh = (int) round($h / $ratio);
        $dst = imagecreatetruecolor($nw, $nh);
        imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
        imagedestroy($src);
        $src = $dst;
    }

    ob_start();
    imagejpeg($src, null, $quality);
    $binary = ob_get_clean() ?: '';
    imagedestroy($src);

    if ($binary === '') throw new RuntimeException('encode_failed');

    return ['binary' => $binary, 'mime' => 'image/jpeg', 'size' => strlen($binary)];
}

/**
 * Normaliza teléfono a dígitos (+ leading opcional).
 */
function phone_normalize(string $p): string
{
    $p = trim($p);
    if ($p === '') return '';
    $leading = str_starts_with($p, '+') ? '+' : '';
    return $leading . preg_replace('/\D+/', '', $p);
}
